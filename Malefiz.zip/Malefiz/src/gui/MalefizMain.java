package gui;

import structure.BoardStructure;

public class MalefizMain {

	public static void main(String[] args) {
		Board board = new Board();
	}
}
